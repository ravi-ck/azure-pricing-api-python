# Azure Pricing API Python
azure-pricing-api is a python wrapper around the Azure Retail Prices Rest API, which helps you to eaily get Azure Retail Prices using python.
We have tried to style it similar to the AWS pricing api.

## Installation
The pricing api could be easily installed by using the following command:

```bash
    pip install azure-pricing-api
```

## Contributing

Pull requests are welcome. For major changes, please open an issue first
to discuss what you would like to change.

## License

[Apache](https://choosealicense.com/licenses/apache-2.0/)
